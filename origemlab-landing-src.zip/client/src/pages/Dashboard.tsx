import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  ArrowLeft, Search, Filter, Globe, TrendingUp, Calendar, 
  DollarSign, Target, CheckCircle2, Clock, AlertCircle,
  Download, Send, Eye, Sparkles, BarChart3, FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface Edital {
  id: string;
  titulo: string;
  orgao: string;
  valor: string;
  prazo: string;
  match: number;
  probabilidade: number;
  pais: string;
  flag: string;
  area: string;
  status: "novo" | "em_analise" | "submetido";
  elegivel: boolean;
  requisitos?: string[];
}

const editaisGlobais: Edital[] = [
  {
    id: "1",
    titulo: "Horizon Europe - EIC Accelerator 2025",
    orgao: "European Innovation Council",
    valor: "€2.500.000",
    prazo: "45 dias",
    match: 96,
    probabilidade: 78,
    pais: "União Europeia",
    flag: "🇪🇺",
    area: "Tecnologia",
    status: "novo",
    elegivel: true,
    requisitos: ["Parceiro europeu necessário", "TRL 6-8", "Potencial de escala global"]
  },
  {
    id: "2",
    titulo: "FAPESP - Pesquisa Inovativa em Pequenas Empresas (PIPE)",
    orgao: "FAPESP",
    valor: "R$ 1.000.000",
    prazo: "30 dias",
    match: 94,
    probabilidade: 82,
    pais: "Brasil",
    flag: "🇧🇷",
    area: "P&D",
    status: "em_analise",
    elegivel: true,
    requisitos: ["Empresa em SP", "Pesquisador doutor", "Contrapartida 10%"]
  },
  {
    id: "3",
    titulo: "Newton Fund - UK-Brazil Research Partnerships",
    orgao: "UK Research and Innovation",
    valor: "£300.000",
    prazo: "60 dias",
    match: 92,
    probabilidade: 75,
    pais: "Reino Unido",
    flag: "🇬🇧",
    area: "Colaboração Internacional",
    status: "novo",
    elegivel: true,
    requisitos: ["Parceria UK-BR obrigatória", "Benefício mútuo", "Cofinanciamento"]
  },
  {
    id: "4",
    titulo: "CORFO - Innovación Empresarial de Alto Impacto",
    orgao: "CORFO Chile",
    valor: "$150.000.000 CLP",
    prazo: "40 dias",
    match: 89,
    probabilidade: 70,
    pais: "Chile",
    flag: "🇨🇱",
    area: "Inovação",
    status: "novo",
    elegivel: true,
    requisitos: ["Operação no Chile", "Inovação radical", "Impacto econômico"]
  },
  {
    id: "5",
    titulo: "FINEP - Subvenção Econômica à Inovação",
    orgao: "FINEP",
    valor: "R$ 3.000.000",
    prazo: "25 dias",
    match: 91,
    probabilidade: 80,
    pais: "Brasil",
    flag: "🇧🇷",
    area: "Inovação",
    status: "novo",
    elegivel: true,
    requisitos: ["Empresa brasileira", "Projeto inovador", "Contrapartida 20%"]
  },
  {
    id: "6",
    titulo: "Marie Skłodowska-Curie Actions - Individual Fellowships",
    orgao: "European Commission",
    valor: "€200.000",
    prazo: "90 dias",
    match: 88,
    probabilidade: 65,
    pais: "União Europeia",
    flag: "🇪🇺",
    area: "Pesquisa",
    status: "novo",
    elegivel: true,
    requisitos: ["Pesquisador individual", "Host institution EU", "Mobilidade internacional"]
  },
  {
    id: "7",
    titulo: "CNPq - Universal",
    orgao: "CNPq",
    valor: "R$ 120.000",
    prazo: "35 dias",
    match: 85,
    probabilidade: 72,
    pais: "Brasil",
    flag: "🇧🇷",
    area: "Pesquisa Básica",
    status: "novo",
    elegivel: true,
    requisitos: ["Doutor", "Vínculo institucional", "Projeto de pesquisa"]
  },
  {
    id: "8",
    titulo: "Minciencias - Proyectos de I+D+i",
    orgao: "Minciencias Colombia",
    valor: "$500.000.000 COP",
    prazo: "50 dias",
    match: 83,
    probabilidade: 68,
    pais: "Colômbia",
    flag: "🇨🇴",
    area: "P&D",
    status: "novo",
    elegivel: true,
    requisitos: ["Colaboração colombiana", "Registro Minciencias", "Cofinanciamento"]
  }
];

export default function Dashboard() {
  const [filtroRegiao, setFiltroRegiao] = useState<string>("todos");
  const [busca, setBusca] = useState("");
  const [, setLocation] = useLocation();

  const handleVerDetalhes = (editalId: string) => {
    setLocation(`/edital/${editalId}`);
  };

  // Filtrar apenas editais do Brasil
  const editaisBrasil = editaisGlobais.filter(e => e.pais === "Brasil");
  
  const editaisFiltrados = editaisBrasil.filter(edital => {
    const matchBusca = edital.titulo.toLowerCase().includes(busca.toLowerCase()) ||
                       edital.orgao.toLowerCase().includes(busca.toLowerCase());
    return matchBusca;
  });

  const stats = {
    editaisAtivos: editaisBrasil.length,
    emAnalise: editaisBrasil.filter(e => e.status === "em_analise").length,
    matchAlto: editaisBrasil.filter(e => e.match >= 90).length,
    propostas: 5 // Mock - número de propostas ativas
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Meu Painel</h1>
                <p className="text-sm text-gray-600">Oportunidades globais de fomento</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/minhas-propostas">
                <Button variant="outline" className="border-violet-600 text-violet-600 hover:bg-violet-50">
                  <FileText className="w-4 h-4 mr-2" />
                  Minhas Propostas
                </Button>
              </Link>
              <Badge className="bg-gradient-to-r from-blue-600 to-violet-600 text-white">
                Plano Pro
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="container py-8">
        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <Target className="w-5 h-5 text-blue-600" />
              <TrendingUp className="w-4 h-4 text-green-600" />
            </div>
            <div className="text-3xl font-bold text-gray-900">{stats.editaisAtivos}</div>
            <div className="text-sm text-gray-600">Editais disponíveis</div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <Sparkles className="w-5 h-5 text-violet-600" />
            </div>
            <div className="text-3xl font-bold text-gray-900">{stats.matchAlto}</div>
            <div className="text-sm text-gray-600">Match acima de 90%</div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <FileText className="w-5 h-5 text-green-600" />
            </div>
            <div className="text-3xl font-bold text-gray-900">{stats.propostas}</div>
            <div className="text-sm text-gray-600">Propostas ativas</div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <BarChart3 className="w-5 h-5 text-orange-600" />
            </div>
            <div className="text-3xl font-bold text-gray-900">{stats.emAnalise}</div>
            <div className="text-sm text-gray-600">Em análise</div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 mb-6">
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Buscar editais..."
                  className="pl-10"
                  value={busca}
                  onChange={(e) => setBusca(e.target.value)}
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                className="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filtroRegiao}
                onChange={(e) => setFiltroRegiao(e.target.value)}
              >
                <option value="todos">Todas as regiões</option>
                <option value="brasil">🇧🇷 Brasil</option>
                <option value="europa">🇪🇺 Europa</option>
                <option value="latam">🌎 América Latina</option>
              </select>
            </div>
          </div>
        </div>

        {/* Editais List */}
        <div className="space-y-4">
          {editaisFiltrados.map((edital) => (
            <div key={edital.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-2xl">{edital.flag}</span>
                    <h3 className="text-lg font-bold text-gray-900">{edital.titulo}</h3>
                    {edital.status === "novo" && (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Novo
                      </Badge>
                    )}
                    {edital.status === "em_analise" && (
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        Em análise
                      </Badge>
                    )}
                  </div>
                  <div className="text-sm text-gray-600 mb-3">{edital.orgao} • {edital.pais}</div>
                  
                  {/* Requisitos */}
                  {edital.requisitos && (
                    <div className="flex flex-wrap gap-2 mb-3">
                      {edital.requisitos.map((req, idx) => (
                        <span key={idx} className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                          {req}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-gray-400" />
                      <span className="font-semibold text-gray-900">{edital.valor}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-600">Prazo: {edital.prazo}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Target className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-600">{edital.area}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-3">
                  {/* Match Score */}
                  <div className="text-right">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="text-3xl font-bold text-blue-600">{edital.match}%</div>
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="text-xs text-gray-600">Match</div>
                  </div>

                  {/* Probabilidade */}
                  <div className="text-right">
                    <div className="text-2xl font-bold text-violet-600">{edital.probabilidade}%</div>
                    <div className="text-xs text-gray-600">Prob. aprovação</div>
                  </div>

                  {/* Elegibilidade */}
                  {edital.elegivel && (
                    <Badge className="bg-green-100 text-green-700 border-green-200">
                      ✓ Elegível
                    </Badge>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3 pt-4 border-t border-gray-200">
                <Button className="flex-1 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Gerar proposta com IA
                </Button>
                <Button variant="outline" onClick={() => handleVerDetalhes(edital.id)}>
                  <Eye className="w-4 h-4 mr-2" />
                  Ver detalhes
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Baixar edital
                </Button>
              </div>
            </div>
          ))}
        </div>

        {editaisFiltrados.length === 0 && (
          <div className="text-center py-12">
            <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Nenhum edital encontrado com os filtros selecionados.</p>
          </div>
        )}
      </div>


    </div>
  );
}
